# Contained herein is my personal Ultramarine Scripts

You can get Ultramarine from here    https://ultramarine-linux.org/

I use KDE Plasma for my DE, but Budgie, GNOME and Pantheon are also avaialble for download.

Some of the inclusions are:

~ flatpak {stable & beta}
~ small tweaks to speed up networks, samba, etc

Fedora is a great distro, and Ultramarine applies tweaks that just makes it better, for my use.