#!/bin/bash
# rpg-cli — your filesystem as a dungeon!
# https://github.com/facundoolano/rpg-cli

# The first time you run the program, a new hero is created at the user's home directory.
# ~ $ rpg

# When running without parameters, as above, the hero status is printed
# (health points, accumulated experience, etc.). The stats are randomized:
# if you run rpg reset you will get a slightly different character every time:
# ~ $ rpg reset; rpg

# You can also pick a different class (default options are warrior, thief and mage).
# For example, the mage class enables magic attacks:
# ~ $ rpg class mage; rpg

# If you use the cd subcommand with a path as parameter, it will instruct the hero to move:
# ~ $ rpg cd dev/
# In this case, the warrior moved to ~/dev. Sometimes enemies will appear as you
# move through the directories, and both characters will engage in battle

# Each character attacks in turn (the frequency being determined by their spd stat).
# Whenever you win a fight, your hero gains experience points and eventually raises its level.
# When you return to home, the hero's health points are restored and status effects removed:
# ~/dev/facundoolano/rpg-cli $ rpg cd ~
# The further from home you move the hero, the tougher the enemies will get.

# Death is permanent: you can't save your progress and reload after dying,
# but if you take your new hero to the location of the previous one's death,
# you can recover gold, items and equipment:
# ~ $ rpg cd ~/dev/facundoolano/rpg-cli/target/debug/

# In addition to winning items as battle rewards, some directories have
# hidden treasure chests that you can find with rpg ls:
# ~ $ rpg ls

# Finally, some items can be bought at the game directory running rpg buy:
# ~ $ rpg buy

# An item can be described with the stat subcommand and used with use:
# ~ $ rpg stat potion
#  potion[1]: restores 25hp
# ~ $ rpg use potion
#  warrior[3][xxxx] +25hp potion

# The rpg todo command will display a list of quest for your hero:
# ~ $ rpg todo

# Each time you complete an item on the list, you will receive a reward.
# The quests renew as your level raises, so be sure to check often!
# The game difficulty increases as you go deeper in the dungeon;
# to raise your level, encounter the tougher enemies, find the rarest items and
# complete all the quests
# It's necessary to go as far as possible from the $HOME directory.

if [ -x "$(command -v rpg-cli)" ]; then

    # You can override this with your own path to rpg-cli
    RPG=$(\which rpg-cli)

    # Use the rpg as the command to do non fs related tasks such as print
    # status and buy items.
    rpg () {
        $RPG "$@"
        sync_rpg
    }

    # Try to move the hero to the given destination, and cd match the shell pwd
    # to that of the hero's location:
    # - the one supplied as parameter, if there weren't any battles
    # - the one where the battle took place, if the hero wins
    # - the home dir, if the hero dies
    rcd () {
        $RPG cd "$@"
        sync_rpg
    }

    # Generate dungeon levels on the fly and look for treasures while moving down.
    #  Will start by creating dungeon/1 at the current directory, and /2, /3, etc.
    #  on subsequent runs.
    dn () {
        current=$(basename $PWD)
        number_re='^[0-9]+$'

        if [[ $current =~ $number_re ]]; then
            next=$(($current + 1))
            command mkdir -p $next && cd $next && rpg ls
        elif [[ -d 1 ]] ; then
            rcd 1 && rpg ls
        else
            command mkdir -p dungeon/1 && cd dungeon/1 && rpg ls
        fi
    }

    # This helper is used to make the pwd match the tracked internally by the game
    sync_rpg () {
        builtin cd "$($RPG pwd)"
    }

fi
