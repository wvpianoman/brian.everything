#!/usr/bin/env bash
#######################################################
# Extreme Ultimate .bashrc - Interactive Installer
#
# This script sets up the Extreme Ultimate .bashrc framework
# after installation via a package manager (AUR) or manual
# download. It respects your existing environment and never
# modifies anything without asking first.
#
# Usage: bash /opt/extreme-ultimate-bashrc/install.sh
#    or: setup-bashrc
#######################################################

# Resolve the directory where this install script lives
# This is also where the framework files are installed
INSTALL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ANSI color codes (can't rely on bashrc colors since it may not be loaded yet)
RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
CYAN='\033[1;36m'
WHITE='\033[1;37m'
RESET='\033[0m'

# Track what we did for the summary
ACTIONS=()
SHELL_CHANGED=false

#######################################################
# Helper Functions
#######################################################

# Print a colored header
header() {
	echo ""
	echo -e "${CYAN}=== ${WHITE}${1}${CYAN} ===${RESET}"
	echo ""
}

# Print an info message
info() {
	echo -e "${CYAN}  ${1}${RESET}"
}

# Print a success message
success() {
	echo -e "${GREEN}  ${1}${RESET}"
}

# Print a warning message
warn() {
	echo -e "${YELLOW}  ${1}${RESET}"
}

# Print an error message
error() {
	echo -e "${RED}  ${1}${RESET}"
}

# Ask a yes/no question, default to the provided value
# Usage: ask "Question?" "Y" (default yes) or ask "Question?" "N" (default no)
ask() {
	local QUESTION="${1}"
	local DEFAULT="${2:-N}"
	local PROMPT

	if [[ "${DEFAULT}" =~ ^[Yy]$ ]]; then
		PROMPT="[Y/n]"
	else
		PROMPT="[y/N]"
	fi

	read -rp "$(echo -e "${WHITE}  ${QUESTION} ${PROMPT} ${RESET}")" REPLY
	REPLY="${REPLY:-${DEFAULT}}"

	[[ "${REPLY}" =~ ^[Yy]$ ]]
}

#######################################################
# Step 1: Check Bash is Installed
#######################################################

if ! command -v bash &>/dev/null; then
	error "Bash is not installed. Please install bash first."
	exit 1
fi

header "Extreme Ultimate .bashrc Installer"
info "This will guide you through setting up the framework."
info "Nothing will be changed without your permission."
echo ""

# Capture the user's current EDITOR before anything overwrites it
# This is used later when generating the config file
ORIGINAL_EDITOR="${EDITOR:-}"
ORIGINAL_VISUAL="${VISUAL:-}"
ORIGINAL_SUDO_EDITOR="${SUDO_EDITOR:-}"
ORIGINAL_FCEDIT="${FCEDIT:-}"

#######################################################
# Step 2: Detect Shell, Warn if Not Bash, Offer chsh
#######################################################

header "Shell Detection"

USER_SHELL="$(basename "${SHELL}")"
BASH_PATH="$(command -v bash)"

if [[ "${USER_SHELL}" == "bash" ]]; then
	success "Your default shell is Bash. Good to go."
else
	warn "Your default shell is ${USER_SHELL}."
	echo ""
	info "This framework is designed for Bash. It uses bash-specific"
	info "syntax (shopt, bind, complete, etc.) and cannot be sourced"
	info "from ${USER_SHELL}."
	echo ""
	info "Options:"
	info "  1) Change your default shell to Bash (requires your password)"
	info "  2) Continue anyway (useful if you run Bash as a secondary shell)"
	info "  3) Exit"
	echo ""

	read -rp "$(echo -e "${WHITE}  Choice [1/2/3]: ${RESET}")" CHOICE
	case "${CHOICE}" in
		1)
			info "Changing default shell to ${BASH_PATH}..."
			if chsh -s "${BASH_PATH}"; then
				success "Default shell changed to Bash."
				warn "You will need to log out and back in for this to take effect."
				SHELL_CHANGED=true
				ACTIONS+=("Changed default shell to Bash")
			else
				error "Failed to change shell. You may need to run: chsh -s ${BASH_PATH}"
			fi
			;;
		2)
			info "Continuing with installation..."
			;;
		*)
			info "Exiting. No changes were made."
			exit 0
			;;
	esac
fi

#######################################################
# Step 3: Replace ~/.bashrc
#######################################################

header "Install .bashrc"

if [[ -f "${HOME}/.bashrc" ]]; then
	# Check if it's already our wrapper
	if grep -q "BASHRC_INSTALL_DIR" "${HOME}/.bashrc" 2>/dev/null && \
	   grep -q "source.*\.bashrc" "${HOME}/.bashrc" 2>/dev/null; then
		success "Your ~/.bashrc is already set up to source the framework."
		info "Skipping this step."
	else
		info "You have an existing ~/.bashrc file."
		echo ""
		if ask "Replace it with the framework? (yours will be backed up)" "Y"; then
			# Create backup with date stamp
			BACKUP_FILE="${HOME}/.bashrc.backup.$(date +%Y%m%d)"

			# If backup already exists today, add time to make it unique
			if [[ -f "${BACKUP_FILE}" ]]; then
				BACKUP_FILE="${HOME}/.bashrc.backup.$(date +%Y%m%d-%H%M%S)"
			fi

			cp "${HOME}/.bashrc" "${BACKUP_FILE}"
			success "Backed up to ${BACKUP_FILE}"

			# Write the thin wrapper
			cat > "${HOME}/.bashrc" << 'BASHRC_WRAPPER'
# Extreme Ultimate .bashrc (managed by package manager)
# Your personal config: ~/.config/bashrc/config
# Your personal aliases: ~/.config/bashrc/aliases
BASHRC_INSTALL_DIR="/opt/extreme-ultimate-bashrc"
source "${BASHRC_INSTALL_DIR}/.bashrc"
BASHRC_WRAPPER

			success "Installed .bashrc wrapper."
			ACTIONS+=("Replaced ~/.bashrc (backup: ${BACKUP_FILE})")
		else
			info "Skipped. You can source it manually by adding this to your ~/.bashrc:"
			info "  BASHRC_INSTALL_DIR=\"${INSTALL_DIR}\""
			info "  source \"\${BASHRC_INSTALL_DIR}/.bashrc\""
		fi
	fi
else
	if ask "No ~/.bashrc found. Create one with the framework?" "Y"; then
		cat > "${HOME}/.bashrc" << 'BASHRC_WRAPPER'
# Extreme Ultimate .bashrc (managed by package manager)
# Your personal config: ~/.config/bashrc/config
# Your personal aliases: ~/.config/bashrc/aliases
BASHRC_INSTALL_DIR="/opt/extreme-ultimate-bashrc"
source "${BASHRC_INSTALL_DIR}/.bashrc"
BASHRC_WRAPPER

		success "Created ~/.bashrc"
		ACTIONS+=("Created ~/.bashrc")
	fi
fi

#######################################################
# Step 4: Ensure .bash_profile Sources .bashrc
#######################################################

header "Login Shell Configuration"

info "Login shells (TTY, SSH, display managers) source"
info "~/.bash_profile instead of ~/.bashrc. Checking..."
echo ""

# Find which profile file bash will use (first match wins)
PROFILE_FILE=""
PROFILE_SOURCES_BASHRC=false

for CANDIDATE in "${HOME}/.bash_profile" "${HOME}/.bash_login" "${HOME}/.profile"; do
	if [[ -f "${CANDIDATE}" ]]; then
		PROFILE_FILE="${CANDIDATE}"
		# Check if it already sources .bashrc
		if grep -qE '(source|\.)\s+.*\.bashrc' "${CANDIDATE}" 2>/dev/null; then
			PROFILE_SOURCES_BASHRC=true
		fi
		break
	fi
done

if [[ -n "${PROFILE_FILE}" ]] && ${PROFILE_SOURCES_BASHRC}; then
	success "${PROFILE_FILE} already sources .bashrc."
elif [[ -n "${PROFILE_FILE}" ]]; then
	warn "${PROFILE_FILE} exists but does not source .bashrc."
	warn "The framework will not load in login shells (TTY, SSH)."
	echo ""
	if ask "Add a source line to ${PROFILE_FILE}?" "Y"; then
		# Append the source line
		echo '' >> "${PROFILE_FILE}"
		echo '# Load .bashrc for login shells' >> "${PROFILE_FILE}"
		echo '[[ -f "${HOME}/.bashrc" ]] && source "${HOME}/.bashrc"' >> "${PROFILE_FILE}"
		success "Added source line to ${PROFILE_FILE}"
		ACTIONS+=("Added .bashrc source line to ${PROFILE_FILE}")
	fi
else
	warn "No .bash_profile, .bash_login, or .profile found."
	warn "The framework will not load in login shells (TTY, SSH)."
	echo ""
	if ask "Create ~/.bash_profile to source .bashrc?" "Y"; then
		cat > "${HOME}/.bash_profile" << 'PROFILE_CONTENT'
# Load .bashrc for login shells
[[ -f "${HOME}/.bashrc" ]] && source "${HOME}/.bashrc"
PROFILE_CONTENT

		success "Created ~/.bash_profile"
		ACTIONS+=("Created ~/.bash_profile")
	fi
fi

#######################################################
# Step 5: Copy Starter Config and Aliases
#######################################################

header "Starter Configuration"

info "The framework uses ~/.config/bashrc/ for your personal"
info "settings. These files are yours and are never overwritten"
info "by package updates."
echo ""

if ask "Set up starter config and aliases in ~/.config/bashrc/?" "Y"; then
	# Create the directory
	mkdir -p "${HOME}/.config/bashrc"

	# Process the config template
	CONFIG_SRC="${INSTALL_DIR}/config.safe"
	CONFIG_DEST="${HOME}/.config/bashrc/config"

	INSTALL_CONFIG=true
	if [[ -f "${CONFIG_DEST}" ]]; then
		warn "~/.config/bashrc/config already exists."
		if ! ask "Overwrite it?" "N"; then
			INSTALL_CONFIG=false
			info "Keeping your existing config."
		fi
	fi

	if ${INSTALL_CONFIG} && [[ -f "${CONFIG_SRC}" ]]; then
		# Build the editor block based on the user's current environment
		if [[ -n "${ORIGINAL_EDITOR}" ]]; then
			EDITOR_BLOCK="export EDITOR=\"${ORIGINAL_EDITOR}\"
export VISUAL=\"${ORIGINAL_VISUAL:-${ORIGINAL_EDITOR}}\"
export SUDO_EDITOR=\"${ORIGINAL_SUDO_EDITOR:-${ORIGINAL_EDITOR}}\"
export FCEDIT=\"${ORIGINAL_FCEDIT:-${ORIGINAL_EDITOR}}\""
		else
			EDITOR_BLOCK="# No editor was detected in your environment.
# The framework will auto-detect one for you.
# To override, uncomment and set your preferred editor:
#export EDITOR=\"nano\"
#export VISUAL=\"nano\"
#export SUDO_EDITOR=\"nano\"
#export FCEDIT=\"nano\""
		fi

		# Replace the placeholder in the template and write to destination
		sed "s|__EDITOR_BLOCK__|${EDITOR_BLOCK}|" "${CONFIG_SRC}" > "${CONFIG_DEST}"

		if [[ -n "${ORIGINAL_EDITOR}" ]]; then
			success "Created config with your editor: ${ORIGINAL_EDITOR}"
		else
			success "Created config (editor will be auto-detected)"
		fi
		ACTIONS+=("Created ~/.config/bashrc/config")
	elif ${INSTALL_CONFIG}; then
		warn "config.safe template not found in ${INSTALL_DIR}"
		warn "Skipping config setup."
	fi

	# Copy the aliases file
	ALIASES_SRC="${INSTALL_DIR}/aliases.safe"
	ALIASES_DEST="${HOME}/.config/bashrc/aliases"

	INSTALL_ALIASES=true
	if [[ -f "${ALIASES_DEST}" ]]; then
		warn "~/.config/bashrc/aliases already exists."
		if ! ask "Overwrite it?" "N"; then
			INSTALL_ALIASES=false
			info "Keeping your existing aliases."
		fi
	fi

	if ${INSTALL_ALIASES} && [[ -f "${ALIASES_SRC}" ]]; then
		cp "${ALIASES_SRC}" "${ALIASES_DEST}"
		success "Created starter aliases."
		ACTIONS+=("Created ~/.config/bashrc/aliases")
	elif ${INSTALL_ALIASES}; then
		warn "aliases.safe not found in ${INSTALL_DIR}"
		warn "Skipping aliases setup."
	fi

	# Copy the example files for reference
	for EXAMPLE_FILE in config.example aliases.example; do
		if [[ -f "${INSTALL_DIR}/${EXAMPLE_FILE}" ]]; then
			cp "${INSTALL_DIR}/${EXAMPLE_FILE}" "${HOME}/.config/bashrc/${EXAMPLE_FILE}"
		fi
	done
fi

#######################################################
# Step 6: Install to /etc/skel
#######################################################

header "New User Defaults"

info "You can install the framework as the default for all"
info "new user accounts created on this system."
echo ""

if ask "Install to /etc/skel/ for future new users? (requires sudo)" "N"; then
	if command -v sudo &>/dev/null; then
		# Create skel config directory
		sudo mkdir -p /etc/skel/.config/bashrc

		# Copy the thin wrapper as the default .bashrc
		sudo tee /etc/skel/.bashrc > /dev/null << 'SKEL_BASHRC'
# Extreme Ultimate .bashrc (managed by package manager)
# Your personal config: ~/.config/bashrc/config
# Your personal aliases: ~/.config/bashrc/aliases
BASHRC_INSTALL_DIR="/opt/extreme-ultimate-bashrc"
source "${BASHRC_INSTALL_DIR}/.bashrc"
SKEL_BASHRC

		# Copy the bash_profile
		sudo tee /etc/skel/.bash_profile > /dev/null << 'SKEL_PROFILE'
# Load .bashrc for login shells
[[ -f "${HOME}/.bashrc" ]] && source "${HOME}/.bashrc"
SKEL_PROFILE

		# Copy starter config (with no editor set, let auto-detect handle it)
		if [[ -f "${INSTALL_DIR}/config.safe" ]]; then
			NO_EDITOR_BLOCK="# No editor preset. The framework will auto-detect one.\n# To override, uncomment and set your preferred editor:\n#export EDITOR=\"nano\"\n#export VISUAL=\"nano\"\n#export SUDO_EDITOR=\"nano\"\n#export FCEDIT=\"nano\""
			sed "s|__EDITOR_BLOCK__|${NO_EDITOR_BLOCK}|" "${INSTALL_DIR}/config.safe" | sudo tee /etc/skel/.config/bashrc/config > /dev/null
		fi

		# Copy starter aliases
		if [[ -f "${INSTALL_DIR}/aliases.safe" ]]; then
			sudo cp "${INSTALL_DIR}/aliases.safe" /etc/skel/.config/bashrc/aliases
		fi

		success "Installed to /etc/skel/"
		info "New user accounts will start with the framework."
		ACTIONS+=("Installed defaults to /etc/skel/")
	else
		error "sudo is not available. Skipping /etc/skel/ setup."
		info "You can do this manually as root later."
	fi
fi

#######################################################
# Step 7: Mark Setup Complete and Print Summary
#######################################################

# Touch the marker file so the first-run nudge stops showing
mkdir -p "${HOME}/.config/bashrc"
touch "${HOME}/.config/bashrc/.installed"

header "Setup Complete"

if [[ ${#ACTIONS[@]} -eq 0 ]]; then
	info "No changes were made."
else
	info "What was done:"
	for ACTION in "${ACTIONS[@]}"; do
		success "  - ${ACTION}"
	done
fi

echo ""

if ${SHELL_CHANGED}; then
	warn "Remember to log out and back in for the shell change to take effect."
	echo ""
fi

info "To customize your setup:"
info "  Edit config:  edit ~/.config/bashrc/config"
info "  Edit aliases: edit ~/.config/bashrc/aliases"
info "  Full options: see config.example and aliases.example"
info "  Run again:    setup-bashrc"
echo ""
