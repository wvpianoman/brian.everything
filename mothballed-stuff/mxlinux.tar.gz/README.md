# Contained herein is my personal MX Linux Scripts

You can download MX from here   https://mxlinux.org/

I use KDE Plasma for my DE, but Fluxbox and Xfce are also avaialble for download.

Some of the inclusions are:

~ flatpak {stable & beta}
~ small tweaks to speed up networks, samba, etc

Let's be completely honest, Debian is a very stable OS, but it is boring as watching paint dry.  I found MX and really like the tools that it provides, so that is why I chose go with it.  The ability to create a live ISO from your running system is a one of the great tools they provide.