sudo cp *.conf /usr/lib64/sysctl.d/
